<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Search extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('helper_model');
    }

    public function searchRecord_post()
    {
        $extra = "";
        $from = "18";
        $to = "45";
        $ageFrom = $this->post('ageFrom');
        $ageTo = $this->post('ageTo');
        $gender = $this->post('gender');
        $religion = $this->post('religion');
        $motherTongue = $this->post('motherTongue');
        $country = $this->post('country');

        if(isset($ageFrom) && $ageFrom != "null"){
            $from = $ageFrom;
        }
        if(isset($ageTo) && $ageTo != "null"){
            $to =  $ageTo;              
        }

        if(isset($gender) && $gender != "" && $gender != "null"){

                $extra .= " AND registration_gender = '$gender' ";

                if(isset($religion) && $religion != "" && $religion != "null"){
                    $extra .= " AND registration_religion = '$religion'";
                }

                if(isset($ageFrom) && $ageFrom != "" && $ageFrom != "null")
                {
                    $extra .= " AND registration_age BETWEEN $from AND $to";
                }
                if(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null")
                {
                    $extra .= " AND registration_mother_tongue = '$motherTongue'";
                }
                if(isset($country) && $country != "" && $country != "null")
                {
                    $extra .= "AND registration_country = '$country'";
                }
            }
        elseif(isset($religion) && $religion != "" && $religion != "null"){
                    $extra .= " AND registration_religion = '$religion'";

                if(isset($ageFrom) && $ageFrom != "" && $ageFrom != "null")
                {
                    $extra .= " AND registration_age BETWEEN $from AND $to";
                }
                if(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null")
                {
                    $extra .= " AND registration_mother_tongue = '$motherTongue'";
                }
                if(isset($country) && $country != "" && $country != "null")
                {
                    $extra .= "AND registration_country = '$country'";
                }
            }
        elseif(isset($ageFrom) && $ageFrom != "" && $ageFrom != "null"){
                    $extra .= " AND registration_age BETWEEN $from AND $to";
            
                if(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null")
                {
                    $extra .= " AND registration_mother_tongue = '$motherTongue'";
                }
                if(isset($country) && $country != "" && $country != "null")
                {
                    $extra .= "AND registration_country = '$country'";
                }
            }
        elseif(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null"){
                $extra .= " AND registration_mother_tongue = '$motherTongue'";
                
                if(isset($country) && $country != "" && $country != "null")
                {
                    $extra .= "AND registration_country = '$country'";
                }
            }
        elseif(isset($country) && $country != "" && $country != "null")
            {
                $extra .= "AND registration_country = '$country'";
            }

        $tableName = REGISTRATION_TABLE;
        $extra = "registration_status = 1 $extra";
        $searchResult = $this->helper_model->select("",$tableName, $extra);
        if($searchResult){
            $message = [
                'records' => $searchResult
            ];
            $this->success_response($message, REST_Controller::HTTP_OK);
                    
        }else{
            $message = [
                'message' => 'No Match Found'
            ];
            $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }      
    }
/***********************/
}