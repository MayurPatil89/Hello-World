<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class SendMessage extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->library('email');
        $this->load->model('helper_model');
    }

    public function sendMessage_post()  
    {
        $id = $this->post('sdmsg_hide');
        @$emailTo = $this->post('emailTo');
        @$loginEmail = $this->post('loginEmail');
        @$subject = $this->post('subject');
        @$fname = $this->post('fname');
        @$lname = $this->post('lname');
        $message = $this->post('msg_subject');
        
        $select = "registration_fname,registration_lname,registration_email";
        $where = "registration_id=".$id;
        $user = $this->helper_model->selectwhere($select,"registration",$where);


        
        $data = array();
        $data['message_date'] = time();
        $data['message_date1'] = date("Y-m-d h:i:sa");
        $data['message_from'] = 161;
        $data['message_to'] = ;
        $data['message_subject'] = $message;
        $table = 'message';

        $ans = $this->helper_model->insert($table,$data);

       print_r($ans);
       exit();

        if(!empty($ans))
        {
            $config['mailtype'] = 'html';
            $this->email->initialize($config);

            $email_body ='<div style="background:#fff; border: 1px solid #b3b3b3; height:auto; width:650;">';
            $email_body .='<div style="margin-left:10px; margin-top: 10px; margin-bottom: 0px;">';
            $email_body .='<img src="'.base_url().'public/images/logo-(1).png" style="align:center; height:150px width: 200px;" />';
            $email_body .='</div>';
            $email_body .='<br/>';
            $email_body .='<div>';
            $email_body .='<div style="background:#d9d9d9; padding:30px">';
            $email_body .= "<b>".$message."</b>";
            $email_body .='<br/>';
            $email_body .='</div>';
            $email_body .='</div>';
            $email_body .='</div>';

            $this->load->library('email');
            $this->email->from('noreply@saiprasadvivah.net');
            $this->email->to($emailTo);
            // $this->email->cc('saiprasadvivah2@gmail.com'); 
            $this->email->subject('Saiprasadvivah:Message From '.$fname.'&nbsp;'.$lname.'Profile Id SPV'.$id);
            $this->email->message($email_body);
            if(!$this->email->send())
            {
                $message = [
                    'message' => 'Mail sending fail Please try again..'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
            else
            {
                $message = [
                'message' => 'Mail Send...'
            ];
            $this->success_response($message, REST_Controller::HTTP_OK);
            }
        }else{
            $message = [
                        'message' => 'Somthing goes wrong'
                    ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }    
    }
/*************/
}