<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Profile extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('helper_model');
    }
/*************For Displaying Profile data********************/
    public function userData_post()  
    {

        $id = $this->post();
        $id = $id[0];
      

        if(isset($id)){
            $tableName = REGISTRATION_TABLE;
            $tableName2 = PARTNER_TABLE;
            $tableName3 = MESSAGE_TABLE;
            $tableName4 = ALBUM_TABLE;
            
            $fields = array(
                            'registration_id' => $id
                        );
          $userRegiData = $this->helper_model->select("",$tableName,$fields);


          $partId = array(
                            'partner_register_id' => $id
                        );
            
            $partnerData = $this->helper_model->select("",$tableName2,$partId);
            
           $fromId = array(
                            'message_from' => $id
                        );
            
            $msgFrom = $this->helper_model->select("",$tableName3,$fromId);
            

            $toId = array(
                            'message_to' => $id
                        );
            
            $msgTo = $this->helper_model->select("",$tableName3,$toId);
           

            $albumId = array(
                            'album_user_id' => $id
                        );
           
            $albumExist = $this->helper_model->select("",$tableName4,$albumId);
           

            if($userRegiData){ 
                $message = [
                    'userData' => $userRegiData,
                    'partnerData' => $partnerData,
                    'msgFrom' => $msgFrom,
                    'msgTo' => $msgTo,
                    'albumExist' => $albumExist
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
                          
            }else{
                $message = [
                    'message' => 'No Data Found'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }      
    }
    /****************Update basic info**********************/
    public function updateBasicInfo_post()  
    {   
        $id = $this->post('hidden_id');
        $religion = $this->post('myaccount_religion');
        $fname = $this->post('myaccount_fname');
        $lname = $this->post('myaccount_lname');
        $gender = $this->post('myaccount_gender');
        $age = $this->post('myaccount_age');
        $motherTounge = $this->post('myaccount_motherTounge');
        if(!isset($motherTounge)){$motherTounge="Not Specified";}
        $spokenLanguage = $this->post('myaccount_spokenLanguage');
        if(!isset($spokenLanguage)){$spokenLanguage="Not Specified";}
        $religion = $this->post('myaccount_religion');
        if(!isset($religion)){$religion="Not Specified";}
        $caste = $this->post('myaccount_caste');
        if(!isset($caste)){$caste="Not Specified";}
        $subCaste = $this->post('myaccount_subCaste');
        if(!isset($subCaste)){$subCaste="Not Specified";}
        $profileCreatedby = $this->post('myaccount_profileCreatedby');
        if(!isset($profileCreatedby)){$profileCreatedby="Not Specified";}
        $maritialStatus = $this->post('myaccount_maritialStatus');
        if(!isset($maritialStatus)){$maritialStatus="Not Specified";}
        $children = $this->post('myaccount_children');
        if(!isset($children)){$children="0";}
        $childrenStatus = $this->post('myaccount_childrenStatus');
        if(!isset($childrenStatus)){$childrenStatus="Not Specified";}
        $subgroup = $this->post('myaccount_subgroup');
        if(!isset($subgroup)){$subgroup="Not Specified";}
        $aboutMyself = $this->post('myaccount_aboutMyself');
        if(!isset($aboutMyself)){$aboutMyself="";}
        $panAdhar = $this->post('myaccount_panAdhar');
        if(!isset($panAdhar)){$panAdhar="";}

        $data = array(
                        'registration_fname' => $fname,
                        'registration_lname' => $lname,
                        'registration_gender' => $gender,
                        'registration_religion' => $religion,
                        'registration_mother_tongue' => $motherTounge,
                        'registration_spoken_language' => $spokenLanguage,
                        'registration_caste' => $caste,
                        'registration_sub_caste' => $subCaste,
                        'registration_profile_createdby' => $profileCreatedby,
                        'registration_maritial_status' => $maritialStatus,
                        'registration_children' => $children,
                        'registration_childrenstatus' => $childrenStatus,
                        'registration_age' => $age,
                        'registration_about_myself' => $aboutMyself,
                        'registration_subgroup' => $subgroup,
                        'registration_pan_adhar' => $panAdhar,
         );
        if(isset($id)){
            $tableName = REGISTRATION_TABLE;
            $columnName = array(
                    'registration_id' => $id,
                    );
            $updateBasicInfo = $this->helper_model->update($tableName,$data,$columnName);
            if($updateBasicInfo){
                $message = [
                    'message' => 'Update Successfull...!!'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Updation Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }      
    }

/****************Update physical info**********************/
    public function updatePhysicalInfo_post()  
    {
        $id = $this->post('hidden_id1');
        $height = $this->post('myaccount_htedit');
        if(!isset($height)){$height="";}
        $weight = $this->post('myaccount_wtedit');
        if(!isset($weight)){$weight="";}
        $bloodGroup = $this->post('myaccount_bldgrpedit');
        if(!isset($bloodGroup)){$bloodGroup="Not Specified";}
        $complexion = $this->post('myaccount_cmplxnedit');
        if(!isset($complexion)){$complexion="Not Specified";}
        $bodyType = $this->post('myaccount_bdtypedit');
        if(!isset($bodyType)){$bodyType="Not Specified";}
        $spectacles = $this->post('myaccount_spectedit');
        if(!isset($spectacles)){$spectacles="Not Specified";}
        $physicalStatus = $this->post('myaccount_phstatusedit');
        if(!isset($physicalStatus)){$physicalStatus="Not Specified";}
        $diet = $this->post('myaccount_dietedit');
        if(!isset($diet)){$diet="Not Specified";}

        $data = array(
                        'registration_height' => $height,
                        'registration_weight' => $weight ,
                        'registration_blood_group' => $bloodGroup,
                        'registration_complexion' => $complexion,
                        'registration_body_type' => $bodyType,
                        'registration_spectacles' => $spectacles,
                        'registration_physicalstatus' => $physicalStatus,
                        'registration_diet' => $diet
         );
        if(!empty($id)){
            $tableName = REGISTRATION_TABLE;
            $columnName = array(
                    'registration_id' => $id,
                    );
            $updateBasicInfo = $this->helper_model->update($tableName,$data,$columnName);
            if($updateBasicInfo){
                $message = [
                    'message' => 'Update Successfull...!!'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Updation Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            $message = [
                        'message' => 'Registration id is required.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }     
    }
    /****************Update Astro info**********************/
    public function updateAstroInfo_post()  
    {
        $id = $this->post('hidden_id2');
        $birthTime = $this->post('myaccount_btimedit');
        if(!isset($birthTime)){$birthTime="";}
        $birthDate = $this->post('myaccount_bdataedit');
        if(!isset($birthDate)){$birthDate="";}
        $birthPlace = $this->post('myaccount_bplacedit');
        if(!isset($birthPlace)){$birthPlace="";}
        $birthCountry = $this->post('myaccount_bcountryedit');
        if(!isset($birthCountry)){$birthCountry="Not Specified";}
        $rashi = $this->post('myaccount_rashiedit');
        if(!isset($rashi)){$rashi="Not Specified";}
        $nakshtra = $this->post('myaccount_nakshatraedit');
        if(!isset($nakshtra)){$nakshtra="Not Specified";}
        $charan = $this->post('myaccount_charanedit');
        if(!isset($charan)){$charan="Not Specified";}
        $gana = $this->post('myaccount_ganaedit');
        if(!isset($gana)){$gana="Not Specified";}
        $nadi = $this->post('myaccount_nadiedit');
        if(!isset($nadi)){$nadi="Not Specified";}
        $manglik = $this->post('myaccount_manglikedit');
        if(!isset($manglik)){$manglik="Not Specified";}
        $horoscope = $this->post('myaccount_horoscopedit');
        if(!isset($horoscope)){$horoscope="Not Specified";}

        $data = array(
                        'registration_birth_time' => $birthTime,
                        'registration_birth_date' => date("Y-m-d",strtotime($birthDate)),
                        'registration_birth_place' => $birthPlace,
                        'registration_country_birth' => $birthCountry,
                        'registration_rashi' => $rashi,
                        'registration_nakshatra' => $nakshtra,
                        'registration_charan' => $charan,
                        'registration_gana' => $gana,
                        'registration_nadi' => $nadi,
                        'registration_manglik' => $manglik,
                        'registration_horoscope' => $horoscope

         );
        if(!empty($id)){
            $tableName = REGISTRATION_TABLE;
            $columnName = array(
                    'registration_id' => $id,
                    );
            $updateBasicInfo = $this->helper_model->update($tableName,$data,$columnName);
            if($updateBasicInfo){
                $message = [
                    'message' => 'Update Successfull...!!'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Updation Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            $message = [
                        'message' => 'Registration id is required.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }     
    }
/**************** Update Contact info **********************/
    public function updateContactInfo_post()  
    {
        $id = $this->post('hidden_id3');
        $addess = $this->post('myaccount_addressedit');
        if(!isset($addess)){$addess="Not Specified";}
        $city = $this->post('myaccount_cityedit');
        if(!isset($city)){$city="Not Specified";}
        $state = $this->post('myaccount_statedit');
        if(!isset($state)){$state="Not Specified";}
        $country = $this->post('myaccount_countryedit');
        if(!isset($country)){$country="Not Specified";}
        $citizenship = $this->post('citizenship');
        if(!isset($citizenship)){$citizenship="Not Specified";}
        $std = $this->post('myaccount_stdcodedit');
        if(!isset($std)){$std="";}
        $telephone = $this->post('myaccount_tnodit');
        if(!isset($telephone)){$telephone="";}
        $mobile1 = $this->post('myaccount_mnoedit');
        if(!isset($mobile1)){$mobile1="";}
        $mobile2 = $this->post('myaccount_mno2edit');
        if(!isset($mobile2)){$mobile2="";}

        $data = array(
                        'registration_contact_address' => $addess,
                        'registration_city' => $city,
                        'registration_state' => $state,
                        'registration_country' => $country,
                        'registration_citizenship' => $citizenship,
                        'registration_std' => $std,
                        'registration_telephone' => $telephone,
                        'registration_mobile1' => $mobile1,
                        'registration_mobile2' => $mobile2

         );
        if(!empty($id)){
            $tableName = REGISTRATION_TABLE;
            $columnName = array(
                    'registration_id' => $id,
                    );
            $updateBasicInfo = $this->helper_model->update($tableName,$data,$columnName);
            if($updateBasicInfo){
                $message = [
                    'message' => 'Update Successfull...!!'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Updation Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            $message = [
                        'message' => 'Registration id is required.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }     
    }

    /**************** Update Career info **********************/
    public function updateCareerInfo_post()  
    {
        $id = $this->post('hidden_id4');
        $highestQuali = $this->post('edit_highestQuali');
        if(!isset($highestQuali)){$highestQuali="Not Specified";}
        $educationLevel = $this->post('edit_education_level');
        if(!isset($educationLevel)){$educationLevel="Not Specified";}
        $educationField = $this->post('edit_education_field');
        if(!isset($educationField)){$educationField="Not Specified";}
        $educationDetail = $this->post('edit_education_detail');
        if(!isset($educationDetail)){$educationDetail="Not Specified";}
        $employedin = $this->post('edit_employedin');
        if(!isset($employedin)){$employedin="Not Specified";}
        $occupation = $this->post('edit_occupation');
        if(!isset($occupation)){$occupation="Not Specified";}
        $occupationDetail = $this->post('edit_occup_details');
        if(!isset($occupationDetail)){$occupationDetail="";}
        $monthlyIncome = $this->post('edit_mincm');
        if(!isset($monthlyIncome)){$monthlyIncome="";}
        $workingMarriage = $this->post('workingMarriage');
        if(!isset($workingMarriage)){$workingMarriage="Not Specified";}

        $data = array(
                        'registration_highest_qualification' => $highestQuali,
                        'registration_education_level' => $educationLevel,
                        'registration_education_field' => $educationField,
                        'registration_education_detail' => $educationDetail,
                        'registration_occupation' => $occupation,
                        'registration_occupation_detail' => $occupationDetail,
                        'registration_employedin' => $employedin,
                        'registration_monthly_income' => $monthlyIncome,
                        'registration_working_marriage' => $workingMarriage

         );
        if(!empty($id)){
            $tableName = REGISTRATION_TABLE;
            $columnName = array(
                    'registration_id' => $id,
                    );
            $updateBasicInfo = $this->helper_model->update($tableName,$data,$columnName);
            if($updateBasicInfo){
                $message = [
                    'message' => 'Update Successfull...!!'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Updation Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            $message = [
                        'message' => 'Registration id is required.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }     
    }
/**************** Update Contact info **********************/
    public function updateFamilyInfo_post()  
    {
        $id = $this->post('hidden_id5');
        $fatherName = $this->post('edit_fathername');
        if(!isset($fatherName)){$fatherName="";}
        $fatherStatus = $this->post('edit_fatherstatus');
        if(!isset($fatherStatus)){$fatherStatus="Not Specified";}
        $motherName = $this->post('edit_mothername');
        if(!isset($motherName)){$motherName="";}
        $motherStatus = $this->post('edit_motherstatus');
        if(!isset($motherStatus)){$motherStatus="Not Specified";}
        $brotherMarried = $this->post('edit_brothermar');
        if(!isset($brotherMarried)){$brotherMarried="";}
        $brotherUnmarried = $this->post('edit_brotherunmar');
        if(!isset($brotherUnmarried)){$brotherUnmarried="";}
        $sisterMarried = $this->post('edit_sistermar');
        if(!isset($sisterMarried)){$sisterMarried="";}
        $sisterUnmarried = $this->post('edit_sisterunmar');
        if(!isset($sisterUnmarried)){$sisterUnmarried="";}
        $livingStatus = $this->post('edit_livstatus');
        if(!isset($livingStatus)){$livingStatus="Not Specified";}
        $familyType = $this->post('edit_famtyp');
        if(!isset($familyType)){$familyType="Not Specified";}
        $familyStatus = $this->post('edit_famstat');
        if(!isset($familyStatus)){$familyStatus="Not Specified";}
        $nativeVillage = $this->post('edit_village');
        if(!isset($nativeVillage)){$nativeVillage="";}
        $nativeDistrict = $this->post('edit_district');
        if(!isset($nativeDistrict)){$nativeDistrict="";}
        $nativeTaluka = $this->post('edit_taluka');
        if(!isset($nativeTaluka)){$nativeTaluka="";}
        $nativeState = $this->post('edit_state');
        if(!isset($nativeState)){$nativeState="";}
        $myFamily = $this->post('edit_abtfamily');
        if(!isset($myFamily)){$myFamily="";}
        
        $data = array(
                        'registration_fathername' => $fatherName,
                        'registration_fatherstatus' => $fatherStatus,
                        'registration_mothername' => $motherName,
                        'registration_motherstatus' => $motherStatus,
                        'registration_brothermarried' => $brotherMarried,
                        'registration_brotherunmarried' => $brotherUnmarried,
                        'registration_sistermarried' => $sisterMarried,
                        'registration_sisterunmarried' => $sisterUnmarried,
                        'registration_livingstatus' => $livingStatus,
                        'registration_familytype' => $familyType,
                        'registration_familystatus' => $familyStatus,
                        'registration_nativevillage' => $nativeVillage,
                        'registration_nativedistrict' => $nativeDistrict,
                        'registration_nativetaluka' => $nativeTaluka,
                        'registration_nativestate' => $nativeState,
                        'registration_myfamily' => $myFamily

         );
        if(!empty($id)){
            $tableName = REGISTRATION_TABLE;
            $columnName = array(
                    'registration_id' => $id,
                    );
            $updateBasicInfo = $this->helper_model->update($tableName,$data,$columnName);
            if($updateBasicInfo){
                $message = [
                    'message' => 'Update Successfull...!!'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Updation Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            $message = [
                        'message' => 'Registration id is required.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }     
    }
/*********** Update Partner Info ************/
public function updatePartnerInfo_post()  
    {
        $id = $this->post('hidden_id6');
        $ageFrom = $this->post('edit_Partnerppage_from');
        if(!isset($ageFrom)){$ageFrom="Not Specified";}
        $ageTo = $this->post('edit_Partnerppage_to');
        if(!isset($ageTo)){$ageTo="Not Specified";}
        $heightFrom = $this->post('edit_Partnerheight_from');
        if(!isset($heightFrom)){$heightFrom="Not Specified";}
        $heightTo = $this->post('edit_Partnerheight_to');
        if(!isset($heightTo)){$heightTo="Not Specified";}
        $maritalStatus = $this->post('edit_partner_maritalstatus');
        if(!isset($maritalStatus)){$maritalStatus="Not Specified";}
        $religion = $this->post('edit_partner_religion');
        if(!isset($religion)){$religion="Not Specified";}
        $caste = $this->post('edit_PartnerCaste');
        if(!isset($caste)){$caste="Not Specified";}
        $interCaste = $this->post('edit_intercast');
        if(!isset($interCaste)){$interCaste="Not Specified";}
        $manglik = $this->post('edit_mangalik');
        if(!isset($manglik)){$manglik="Not Specified";}
        $diet = $this->post('edit_PartnerDiet');
        if(!isset($diet)){$diet="Not Specified";}
        $smoke = $this->post('edit_PartnerSmoke');
        if(!isset($smoke)){$smoke="Not Specified";}
        $drink = $this->post('edit_PartnerDrink');
        if(!isset($drink)){$drink="Not Specified";}
        $complexion = $this->post('edit_PartnerComplexion');
        if(!isset($complexion)){$complexion="Not Specified";}
        $bodyType = $this->post('edit_PartnerBodyType');
        if(!isset($bodyType)){$bodyType="Not Specified";}
        $educationLevel = $this->post('edit_partner_educationlevel');
        if(!isset($educationLevel)){$educationLevel="Not Specified";}
        $employedLevel = $this->post('edit_Partneremploylevel');
        if(!isset($employedLevel)){$employedLevel="Not Specified";}
        $occupation = $this->post('edit_Occupation');
        if(!isset($occupation)){$occupation="";}
        $monthlyIncome = $this->post('edit_MonthlyIncome');
        if(!isset($monthlyIncome)){$monthlyIncome="";}
        $subgroup = $this->post('edit_subgroup');
        if(!isset($subgroup)){$subgroup="Not Specified";}
        $city = $this->post('edit_PartnerCity');
        if(!isset($city)){$city="Not Specified";}
        $state = $this->post('edit_PartnerState');
        if(!isset($state)){$state="Not Specified";}
        $country = $this->post('edit_PartnerCountry');
        if(!isset($country)){$country="Not Specified";}
        $aboutPartner = $this->post('edit_abtpartner');
        if(!isset($aboutPartner)){$aboutPartner="";}

        $data = array(
                        'partner_register_id' => $id,
                        'partner_agefrom' => $ageFrom,
                        'partner_ageto' => $ageTo,
                        'partner_heightfrom' => $heightFrom,
                        'partner_heightto' => $heightTo,
                        'partner_maritalstatus' => $maritalStatus,
                        'partner_religion' => $religion,
                        'partner_caste' => $caste,
                        'partner_intercaste' => $interCaste,
                        'partner_manglik' => $manglik,
                        'partner_bodytype' => $bodyType,
                        'partner_educationlevel' => $educationLevel,
                        'partner_employedlevel' => $employedLevel,
                        'partner_diet' => $diet,
                        'partner_smoke' => $smoke,
                        'partner_drink' => $drink,
                        'partner_complexion' => $complexion,
                        'partner_occupation' => $occupation,
                        'partner_monthlyincome' => $monthlyIncome,
                        'partner_subgroup' => $subgroup,
                        'partner_city' => $city,
                        'partner_state' => $state,
                        'partner_country' => $country,
                        'partner_aboutpartner' => $aboutPartner

         );
    if(!empty($id)){
            $tableName = 'partner_preference';
            // $columnName = array(
            //         'partner_register_id' => $id,
            //         );
            $updateBasicInfo = $this->helper_model->insert($tableName,$data);
            if($updateBasicInfo){
                $message = [
                    'message' => 'Update Successfull...!!'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Updation Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            $message = [
                        'message' => 'Registration id is required.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }     
    }
/*************/

}