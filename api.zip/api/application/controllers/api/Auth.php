<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Auth extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('helper_model');
    }

    public function userLogin_post()
    {
        //echo json_encode($this->post('username'));

        $username = $this->post('username');
        $password = $this->post('password');

        if(!empty($username) && !empty($password))
        {
            $tableName = REGISTRATION_TABLE;
            $fields = array(
                        'registration_email' => strtolower($username),
                        'registration_password' => $password
                    );

            $userExist = $this->helper_model->select("",$tableName, $fields);
            if($userExist){  
                if($userExist[0]['registration_status'] ==1){
                    $message = [
                        'user' => $userExist,
                        
                    ];
                    $this->success_response($message, REST_Controller::HTTP_OK);
                }else {
                    $message = [
                    'message' => 'Please Wait For Admin Approval'
                ];
                $this->error_response($message, REST_Controller::HTTP_OK);
                }           
            }else{
                $message = [
                    'message' => 'Incorrect username and password'
                ];
                $this->error_response($message, REST_Controller::HTTP_OK);
            }
        }else {
            $message = [
                    'message' => 'Both username and password is required'
                ];
                $this->error_response($message, REST_Controller::HTTP_OK);
        }        
    }

    public function registerUser_post()
    {
        
       $username = $this->post('basic_info_email');
       $password = $this->post('basic_info_password');
       $mobile = $this->post('basic_info_mobile');


        $otp = rand(1000,9999);
        if(!empty($username) && !empty($password) && !empty($mobile))
        {

            $tableName = REGISTRATION_TABLE;

            $fields = array(
                        'registration_email' => strtolower($username)
                    );

            $userExist = $this->helper_model->select('',$tableName,$fields);

            if($userExist){            
                $message = [
                    'message' => 'Username Name allready Exist'
                ];

                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);            
            }else{
                $fields = array(
                        'registration_email' => strtolower($username),
                        'registration_password' => $password,
                        'registration_mobile1' => $mobile,
                        'registration_r_verify_otp' => $otp
                    );

                $userInsert = $this->helper_model->insert($tableName, $fields);
                if($userInsert){            
                    $message = [
                        'userInsertId' => $userInsert,
                        'success' => '1'
                    ];
                    $this->success_response($message, REST_Controller::HTTP_OK);            
                }else{
                    $message = [
                        'message' => 'Incorrect Data',
                        'success' => '0'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
                }  
            }
        }else{
            $message = [
                        'message' => 'All field are compulsory'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }        
    }

   public function verifyOtp_post()
    {

        $registration_id = $this->post('registration_id');
        $insert_otp = $this->post('insert_otp');
       
         if(!empty($registration_id) && !empty($insert_otp))
        {
            $tableName = REGISTRATION_TABLE;

            $fields = array(
                        'registration_id' => $registration_id,
                        'registration_r_verify_otp' => $insert_otp
                    );
          
            $verifyOtp = $this->helper_model->select('',$tableName,$fields);

            if($verifyOtp){ 
                $data = array('registration_is_verify' => 1);
                $columnName = array('registration_id' => $verifyOtp[0]['registration_id']);
                $updateIsverify = $this->helper_model->update($tableName,$data,$columnName);

                if($updateIsverify){            
                    $message = [
                        'message' => $verifyOtp[0]['registration_id']
                    ];
                    $this->success_response($message, REST_Controller::HTTP_OK);   
                }else{
                    $message = [
                        'message' => 'Is verfy updation fail'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST); 
                }       
            }else{
                $message = [
                        'message' => 'OTP does not match'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);           
                } 
        }
        else
        {
            $message = [
                        'message' => 'All field are compulsory'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }        
    }

    public function updateUser_post()
    {   
        $id = $this->post('hidden_id1');
        $fname = $this->post('basic_info_fname');
        $lname = $this->post('basic_info_lname');
        $gender = $this->post('basic_info_gender');
        $panAdhar = $this->post('basic_info_pan');
        $birthDate = $this->post('birthDate');
        $motherTounge = $this->post('basic_info_mothertounge');
        if(!isset($motherTounge)){$motherTounge="Not Specified";}
        $spokenLanguage = $this->post('basic_info_spoken_language');
        if(!isset($spokenLanguage)){$spokenLanguage="Not Specified";}
        $religion = $this->post('basic_info_religion');
        if(!isset($religion)){$religion="Not Specified";}
        $caste = $this->post('basic_info_cast');
        if(!isset($caste)){$caste="Not Specified";}
        $subCaste = $this->post('basic_info_subcast');
        if(!isset($subCaste)){$subCaste="Not Specified";}
        $profileCreatedby = $this->post('basic_info_profile-for');
        if(!isset($profileCreatedby)){$profileCreatedby="Not Specified";}
        $maritialStatus = $this->post('basic_info_marital-status');
        if(!isset($maritialStatus)){$maritialStatus="Not Specified";}
        $children = $this->post('basic_info_children');
        if(!isset($children)){$children="0";}
        $childrenStatus = $this->post('basic_info_children_living_status');
        if(!isset($childrenStatus)){$childrenStatus="Not Specified";}
        $subgroup = $this->post('basic_info_group');
        if(!isset($subgroup)){$subgroup="Not Specified";}
        $aboutMyself = $this->post('basic_info_about');
        if(!isset($aboutMyself)){$aboutMyself="";}
        $mobile2 = $this->post('basic_info_mobile2');
        if(!isset($mobile2)){$mobile2="";}
        $address = $this->post('basic_info_address');
        if(!isset($address)){$address="";}
        $city = $this->post('basic_info_city');
        if(!isset($city)){$city="";}
        $state = $this->post('basic_info_state');
        if(!isset($state)){$state="";}
        $country = $this->post('basic_info_country');
        if(!isset($country)){$country="";}
        $citizenship = $this->post('basic_info_citizenship');
        if(!isset($citizenship)){$citizenship="";}
        $std_code = $this->post('std_code');
        if(!isset($std_code)){$std_code="";}
        $tno = $this->post('tno');
        if(!isset($tno)){$tno="";}


       if(!empty($id) && !empty($fname) && !empty($lname) && !empty($gender) && !empty($panAdhar) && !empty($birthDate))
        {
            $tableName = REGISTRATION_TABLE;
            
            // $dob=explode("-",$birthDate); 
            // $curMonth = date("m");
            // $curDay = date("j");
            // $curYear = date("Y");
         
           // $age = $curYear - $dob[0]; 
            // if($curMonth<$dob[1] || ($curMonth==$dob[1] && $curDay<$dob[2])) 
            //         $age--;
          

            $data = array(
                    'registration_fname' => $fname,
                    'registration_lname' => $lname,
                    'registration_gender' => $gender,
                    'registration_pan_adhar' => $panAdhar,
                    'registration_birth_date' => date("Y-m-d",strtotime($birthDate)),
                    'registration_mother_tongue' => $motherTounge,
                    'registration_spoken_language' => $spokenLanguage,
                    'registration_religion' => $religion,
                    'registration_caste' => $caste,
                    'registration_sub_caste' => $subCaste,
                    'registration_profile_createdby' => $profileCreatedby,
                    'registration_maritial_status' => $maritialStatus,
                    'registration_children' => $children,
                    'registration_childrenstatus' => $childrenStatus,
                    'registration_subgroup' => $subgroup,
                    'registration_about_myself' => $aboutMyself,
                    //'registration_age' => $age,
                    'registration_mobile2' => $mobile2,
                    'registration_contact_address' =>  $address,
                    'registration_city' => $city,
                    'registration_state' => $state,
                    'registration_country' => $country,
                    'registration_citizenship' => $citizenship,
                    'registration_std' => $std_code,
                    'registration_telephone' => $tno
                    );
         $columnName = array(
                    'registration_id' => $id,
                    'registration_is_verify' => 1
                    );
            $updateUser = $this->helper_model->update($tableName,$data,$columnName);
            if($updateUser){
                $message = [
                    'message' => 'Congradulations !! You Have Done Initial Stage Successfully !',
                    'message' => $id
                    ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Insertion Fail, somthing goes wrong.'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }

        else{
            $message = [
                        'message' => 'All field are compulsory'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }        
    }

    public function forgotPassword_post()
    {
        $username = $this->post('username');
        $otp = rand(1000,9999);
        if(!empty($username))
        {
            $tableName = REGISTRATION_TABLE;


            $fields = array(
                        'registration_email' => strtolower($username),
                        'registration_status' =>1
                    );
            $verifyUser = $this->helper_model->select('registration_id',$tableName,$fields);
            if($verifyUser){ 
                $data = array('registration_pass_otp' => $otp);
                $columnName = array('registration_id' => $verifyUser[0]['registration_id']);
                $updateOtp = $this->helper_model->update($tableName,$data,$columnName);

                if($updateOtp){            
                    $message = [
                        'message' => $verifyUser[0]['registration_id']
                    ];
                    $this->success_response($message, REST_Controller::HTTP_OK);   
                }else{
                    $message = [
                        'message' => 'OTP updation fail'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST); 
                }      
            }else{
                $message = [
                        'message' => 'Email id does not Exist'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);           
                } 
        }else{
            $message = [
                        'message' => 'Email id is compulsory'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }        
    }

    public function verifyFpassOtp_post()
    {
        $id = $this->post('id');
        $otp = $this->post('otp');
        if(!empty($id) && !empty($otp))
        {
            $tableName = REGISTRATION_TABLE;

            $fields = array(
                        'registration_id' => $id,
                        'registration_pass_otp' =>$otp
                    );
            $verifyUser = $this->helper_model->select('registration_id',$tableName,$fields);
            if($verifyUser){
                    $message = [
                        'message' => $verifyUser[0]['registration_id']
                    ];
                    $this->success_response($message, REST_Controller::HTTP_OK);
            }else{
                $message = [
                        'message' => 'Invalid OTP. Please Enter Valid OTP'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);           
                } 
        }else{
            $message = [
                        'message' => 'All field are compulsory'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }        
    }

    public function resetPass_post()
    {   
        
        $id = $this->post('old_passwordid');
        $password = $this->post('new_password');
        if(!empty($id) && !empty($password))
        {
            $tableName = REGISTRATION_TABLE;
 
            $data = array('registration_password' => $password);
            $columnName = array('registration_id' => $id);
            $updateOtp = $this->helper_model->update($tableName,$data,$columnName);

            if($updateOtp){            
                $message = [
                    'message' => 'Password Updated'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);   
            }else{
                $message = [
                    'message' => 'OTP updation fail'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST); 
            } 
        }else{
            $message = [
                        'message' => 'Password is compulsory'
                    ];
                    $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }        
    }

/***************************************************/
}