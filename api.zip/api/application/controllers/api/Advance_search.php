<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Advance_search extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('helper_model');
    }

    public function advanceSearch_post()
    {
        $extra = "";
        $ageFrom = "18";
        $to = "45";
        $height_from ="4"; 
        $height_to = "8";

        $ageFrom = $this->post('ageFrom');
        $ageTo = $this->post('ageTo');
        $fromHeight = $this->post('PartnerFromheight');
        $toHeight = $this->post('PartnerToheight');
        $gender = $this->post('gender');
        $maritialStatus = $this->post('maritialStatus');
        $educationLevel = $this->post('educationLevel');
        $motherTongue = $this->post('motherTongue');
        $city = $this->post('city');
        $fname = $this->post('fname');
        $lname = $this->post('lname');
        $profileId = $this->post('profileId');

        if(isset($ageFrom) && $ageFrom != "null"){
            $from = $ageFrom;
        }
        if(isset($ageTo) && $ageTo != "null"){
            $to =  $ageTo;              
        }
        if(isset($fromHeight) && $fromHeight != "null"){
            $height_from = $fromHeight;
        }
        if(isset($toHeight) && $toHeight != "null"){
            $height_to =  $toHeight;    
        }

        if(isset($gender) && $gender != "" && $gender != "null"){

                $extra .= " AND registration_gender = '$gender' ";

                if(isset($maritialStatus) && $maritialStatus != "" && $maritialStatus != "null"){
                    $extra .= " AND registration_maritial_status = '$maritialStatus'";
                }

                if(isset($ageFrom) && $ageFrom != "" && $ageFrom != "null")
                {
                    $extra .= " AND registration_age BETWEEN $from AND $to";
                }
                if(isset($fromHeight) && $fromHeight != "" && $fromHeight != "null")
                {
                    $extra .= " AND registration_height BETWEEN $height_from AND $height_to";
                }
                if(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null")
                {
                    $extra .= " AND registration_mother_tongue = '$motherTongue'";
                }
                if(isset($educationLevel) && $educationLevel != "" && $educationLevel != "null")
                {
                    $extra .= "AND registration_education_level = '$educationLevel'";
                }
                if(isset($city) && $city != "" && $city != "null")
                {
                    $extra .= "AND registration_city = '$city'";
                }
            }
        elseif(isset($maritialStatus) && $maritialStatus != "" && $maritialStatus != "null"){
                $extra .= " AND registration_maritial_status = '$maritialStatus'";

                if(isset($ageFrom) && $ageFrom != "" && $ageFrom != "null")
                {
                    $extra .= " AND registration_age BETWEEN $from AND $to";
                }
                if(isset($fromHeight) && $fromHeight != "" && $fromHeight != "null")
                {
                    $extra .= " AND registration_height BETWEEN $height_from AND $height_to";
                }
                if(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null")
                {
                    $extra .= " AND registration_mother_tongue = '$motherTongue'";
                }
                if(isset($educationLevel) && $educationLevel != "" && $educationLevel != "null")
                {
                    $extra .= "AND registration_education_level = '$educationLevel'";
                }
                if(isset($city) && $city != "" && $city != "null")
                {
                    $extra .= "AND registration_city = '$city'";
                }
            }
        elseif(isset($ageFrom) && $ageFrom != "" && $ageFrom != "null"){
                $extra .= " AND registration_age BETWEEN $from AND $to";
    
                if(isset($fromHeight) && $fromHeight != "" && $fromHeight != "null")
                {
                    $extra .= " AND registration_height BETWEEN $height_from AND $height_to";
                }
                if(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null")
                {
                    $extra .= " AND registration_mother_tongue = '$motherTongue'";
                }
                if(isset($educationLevel) && $educationLevel != "" && $educationLevel != "null")
                {
                    $extra .= "AND registration_education_level = '$educationLevel'";
                }
                if(isset($city) && $city != "" && $city != "null")
                {
                    $extra .= "AND registration_city = '$city'";
                }
            }
        elseif(isset($fromHeight) && $fromHeight != "" && $fromHeight != "null"){
            $extra .= " AND registration_height BETWEEN $height_from AND $height_to";
    
            if(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null")
            {
                $extra .= " AND registration_mother_tongue = '$motherTongue'";
            }
            if(isset($educationLevel) && $educationLevel != "" && $educationLevel != "null")
            {
                $extra .= "AND registration_education_level = '$educationLevel'";
            }
            if(isset($city) && $city != "" && $city != "null")
            {
                $extra .= "AND registration_city = '$city'";
            }
        }
        elseif(isset($motherTongue) && $motherTongue != "" && $motherTongue != "null"){
            $extra .= " AND registration_mother_tongue = '$motherTongue'";
        
            if(isset($educationLevel) && $educationLevel != "" && $educationLevel != "null")
            {
                $extra .= "AND registration_education_level = '$educationLevel'";
            }
            if(isset($city) && $city != "" && $city != "null")
            {
                $extra .= "AND registration_city = '$city'";
            }
        }
        elseif(isset($educationLevel) && $educationLevel != "" && $educationLevel != "null"){
                $extra .= "AND registration_education_level = '$educationLevel'";
            
            if(isset($city) && $city != "" && $city != "null")
            {
                $extra .= "AND registration_city = '$city'";
            }
        }
        elseif(isset($city) && $city != "" && $city != "null"){
            $extra .= "AND registration_city = '$city'";
        }

        elseif(isset($fname) && $fname != "null"){
            $extra .= "AND registration_fname = '$fname'";
            
            if(isset($lname) && $lname != "" && $lname != "null"){
                $extra .= " AND registration_lname = '$lname'";
            }
        }
        elseif(isset($fname) && $fname != "" && $fname != "null"){
            $extra .= " AND registration_lname = '$lname'";
        }

        elseif(isset($profileId) && $profileId != "" && $profileId != "null"){
            $profileId = substr($profileId,3);
            $extra .= "AND registration_id = '$profileId'";      
        }

        $tableName = REGISTRATION_TABLE;
        $extra = "registration_status = 1 $extra";
        $searchResult = $this->helper_model->select("",$tableName, $extra);
        if($searchResult){
            $message = [
                'records' => $searchResult
            ];
            $this->success_response($message, REST_Controller::HTTP_OK);
                    
        }else{
            $message = [
                'message' => 'No Match Found'
            ];
            $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }      
    }
/***********************/
}