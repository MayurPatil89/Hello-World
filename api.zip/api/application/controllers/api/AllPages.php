<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class AllPages extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('helper_model');
    }

    public function getSinglePage_post()
    {
        $pageId = $this->post('pageId');
        if(!empty($pageId))
        {
            $tableName = PAGES_TABLE;
            $field = array(
                'pages_id' => $pageId
                );
            $pageExist = $this->helper_model->select("",$tableName,$field);
            if($pageExist){ 
                $message = [
                    'pageData' => $pageExist
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
                          
            }else{
                $message = [
                    'message' => 'Page Not Found'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }else {
            $message = [
                    'message' => 'Page Not Found'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }         
    }
/*************/
}