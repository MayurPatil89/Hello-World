<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class NewMembers extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('helper_model');
        $this->load->model('member_model');
    }

    public function displayNewMembers_post()
    {
        // $id = $this->post();
        // $id = $id[0];
         $tableName = 'registration';
         $select= "*";
         $where = 'registration_status = 1';
         $order_id='registration_id';
         $order='DESC';
         $num=20;

        $result=$this->member_model->selectallWhereOrder($select,$tableName,$where,$order_id,$order,$num);

            if($result==true)
            { 
                $message = [
                    'userData' => $result
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
                          
            }
            else
            {
                $message = [
                    'message' => 'No Data Found'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }       
    }

    public function showInfo_post()
    {
         $id = $this->post();
         $id = $id[0];
         $tableName='registration';
         $select='*';
         $where='registration_id='.$id;
         $result=$this->helper_model->selectwhere($select, $tableName, $where);
    
         if($result==true)
        { 
                $message = [
                    'userData' => $result
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
                          
         }
        else
         {
                $message = [
                    'message' => 'No Data Found'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
          }
    }

    public function showFullProfile_POST()
    {

        $id = $this->post();
        $id = $id[0];
        if(isset($id))
        {
            $tableName = REGISTRATION_TABLE;
            $tableName2 = PARTNER_TABLE;
            $select="*";
            
            $fields = array(
                            'registration_id' => $id
                        );
            $userRegiData = $this->helper_model->select($select,$tableName,$fields);

            $partId = array(
                            'partner_register_id' => $id
                        );
            
            $partnerData = $this->helper_model->select($select,$tableName2,$partId);

            if($userRegiData)
            { 
                $message = [
                    'userData' => $userRegiData,
                    'partnerData' => $partnerData
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
                          
            }
            else
            {
                $message = [
                    'message' => 'No Data Found'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }      
    }

    public function partnerPrefer_post()
    {
        $id=$this->post();
        $id = $id[0];
     
        $tableName='registration r, partner_preference p';
        $select='r.registration_gender, p.*';
        $where='r.registration_id=p.partner_register_id AND registration_id='.$id;
        $check=$this->helper_model->selectwhere($select, $tableName, $where);
        
        $g=$check[0]['registration_gender'];
        $height_from=$check[0]['partner_heightfrom'];
        $height_to=$check[0]['partner_heightto'];
        $partner_agefrom=$check[0]['partner_agefrom'];
        $partner_ageto=$check[0]['partner_ageto'];
        $partner_maritalstatus=$check[0]['partner_maritalstatus'];
        $partner_manglik=$check[0]['partner_manglik'];
        $partner_educationlevel=$check[0]['partner_educationlevel'];

        if(empty($g))
        {
            $tableName='registration';
            $select="*";
            $order_id='registration_id';
            $order='DESC';
            $num=20;

            $result=$this->member_model->selectOrder($select,$tableName,$order_id,$order, $num);

            $message = [
                    'userData' => $result
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
        }
        else 
        {
            $gender1="";
            if($g=="male")
            {
                $gender1='female';
            }
            else if($g== "female")
            {
               $gender1='male';
            }

            $extra='registration_status = 1 AND registration_gender='."'$gender1'";

            if(isset($height_from) && $height_from!="" && $height_from!="null")
            {
                $extra .= ' AND registration_height between '."'$height_from'".' and '."'$height_to'";
            }

            if(isset( $partner_agefrom) &&  $partner_agefrom!="" &&  $partner_agefrom!="null")
            {
                $extra .= 'OR registration_age between '. "'$partner_agefrom'".' and '."' $partner_ageto'";
            }

            if(isset( $partner_maritalstatus) &&  $partner_maritalstatus!="" &&  $partner_maritalstatus!="null")
            {
                $extra .= ' AND registration_maritial_status='."'$partner_maritalstatus'";
            }

            if(isset($partner_manglik) && $partner_manglik!="" && $partner_manglik!="null")
            {
                $extra .= ' OR registration_manglik='."'$partner_manglik'";
            }
  
            if(isset($partner_educationlevel) && $partner_educationlevel!="" && $partner_educationlevel!="null")
            {
                $extra .=' OR registration_education_level= '."'$partner_educationlevel'";
            }
             
            $query="select * from registration where "."$extra"." order by registration_id DESC limit 20";
         
            $result=$this->member_model->selectQuery($query);
         
            if($result==true)
            { 
                $message = [
                    'userData' => $result
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);        
            }
            else
            {
                $message = [
                    'message' => 'No Data Found'
                ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }
}  