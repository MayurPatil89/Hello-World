<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class ContactUs extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->library('email');
        $this->load->model('helper_model');
    }

    public function contactUs_post()  
    {
        $email = $this->post('email');
        $name = $this->post('name');
        $mobile = $this->post('mobile');
        $subject = $this->post('subject');
        $message = $this->post('message');

        if(!empty($email))
        {
            $config['mailtype'] = 'html';
            $this->email->initialize($config);

            $email_body ='<div style="background:#fff; border: 1px solid #b3b3b3; height:auto; width:650;">';
            $email_body .='<div style="margin-left:10px; margin-top: 10px; margin-bottom: 0px;">';
            $email_body .='<img src="'.base_url().'public/images/logo-(1).png" style="align:center; height:150px width: 200px;" />';
            $email_body .='</div>';
            $email_body .='<br/>';      
            $email_body .='<div>';
            $email_body .='<div style="background:#d9d9d9; padding:30px">';
            $email_body .= "<b>Dear Sir/Madam,</b>";
            $email_body .='<br/>';
            $email_body .='<br/>';
            $email_body .= "<span><b>Following Contacts have been captured from website.</b></span>";
            $email_body .='<br/>';
            $email_body .= "<span><b>Name :</b></span>".$name;
            $email_body .='<br/>';
            $email_body .= "<span><b>Contact No :</b></span>".$mobile;
            $email_body .='<br/>';
            $email_body .= "<span><b>Message :</b></span>".$message;
            $email_body .='<br/>';
            $email_body .='<br/>';
            
            $email_body .='</div>';
            $email_body .='</div>';
            $email_body .='</div>';

            $this->load->library('email');
            $this->email->from($email);
            //$this->email->to("saiprasadvivah@gmail.com");
            $this->email->to("dhananjaypingale2112@gmail.com");
            $this->email->subject($subject);
            $this->email->message($email_body);
            if(!$this->email->send())
            {
                $message = [
                        'message' => 'Mail sending fail Please try again..'
                    ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
            }
            else
            {
                $message = [
                    'message' => 'Mail Send...'
                ];
                $this->success_response($message, REST_Controller::HTTP_OK);
            }
        }else{
            $message = [
                        'message' => 'Email id required'
                    ];
                $this->error_response($message, REST_Controller::HTTP_BAD_REQUEST);
        }    
    }
/*************/
}