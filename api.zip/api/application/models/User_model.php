<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {

	function __construct(){
		// Call the Model constructor
		parent::__construct();
	}

	public function select($select,$tableName,$extra)
	{
		$extra = "registration_status = 1 $extra";
		$this->db->from($tableName);
		$this->db->where($extra);
		$query = $this->db->get();
		return $query->result_array();
	}

}