<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Member_model extends CI_Model {

	function __construct(){
		// Call the Model constructor
		parent::__construct();
	}

	public function selectOrder($select,$tableName,$order_id,$order, $num)
	{
		$this->db->select($select);
		$this->db->from($tableName);
		$this->db->order_by($order_id, $order);
		$this->db->limit($num);
		$query = $this->db->get();
		return $query->result_array();
	}

	public function selectallWhereOrder($select,$tableName,$where,$order_id,$order,$num)
	{
		$this->db->select($select);
		$this->db->from($tableName);
		$this->db->where($where);
		$this->db->order_by($order_id, $order);
		$this->db->limit($num);
		$query = $this->db->get();
	    return  $query->result_array();
	    //$this->db->last_query();
	}

	public function selectQuery($query)
	{
		$result = $this->db->query($query);
      	 return $result->result_array();
        // $this->db->last_query();
	}
}	